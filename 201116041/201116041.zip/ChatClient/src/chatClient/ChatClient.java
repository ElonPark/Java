package chatClient;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Scanner;

public class ChatClient
{
    
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        try
        {
            InetSocketAddress socketAddress = new InetSocketAddress(
                    "192.168.36.91", 9000);
            Socket socket = new Socket();
            
            socket.connect(socketAddress, 10000);
            
            InetAddress inetaddr;
            if ((inetaddr = socket.getInetAddress()) != null)
            {
                System.out.println("����: " + inetaddr);
            }
            else
            {
                System.out.println("�������: " + inetaddr);
            }
            
            while (true)
            {
                
                // ���� �޽���
                System.out.print("���� �޽���: ");
                String msg = sc.next();
                
                PrintWriter writer = new PrintWriter(socket.getOutputStream(),true);
                writer.println(msg); // send
                
                // ���� �޽���
                BufferedReader reader = new BufferedReader(
                        new InputStreamReader(socket.getInputStream()));
                        
                String line = reader.readLine(); // ��Ŷ, ���ڿ��� �о ����
                
                System.out.println("���� �޽���: " + line);
                
              //  writer.close();
                //socket.close();
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        
    }
    
}
