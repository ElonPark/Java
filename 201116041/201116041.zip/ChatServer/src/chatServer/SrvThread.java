package chatServer;

import java.net.*;
import java.io.*;

public class SrvThread extends Thread
{
    private Socket soc;
    
    public SrvThread(Socket sc)
    {
        soc = sc;
        System.out.println("����: " + soc.getInetAddress());
    }
    
    @Override
    public void run()
    {
        try
        {
            //recv
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(soc.getInputStream()));
                    
            String line = reader.readLine(); // ��Ŷ, ���ڿ��� �о ����
            
            System.out.println("���� �޽���: " + line);
            
            
            //send
            PrintWriter sendout = new PrintWriter(soc.getOutputStream(),true);
            sendout.println(line);
            
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                if (soc != null)
                {
                    soc.close();
                }
            }
            catch (IOException ioex)
            {
                ioex.printStackTrace();
            }
        }
    }
}
