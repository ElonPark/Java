package myChatSvr;


public class Moviemenu {
  private String movie;
  private String quest;
  private String hint1;
  private String hint2;
  private String hint3;
  private String chr;
public String getMovie() {
	return movie;
}
public void setMovie(String movie) {
	this.movie = movie;
}
public String getQuest() {
	return quest;
}
public void setQuest(String quest) {
	this.quest = quest;
}
public String getHint1() {
	return hint1;
}
public void setHint1(String hint1) {
	this.hint1 = hint1;
}
public String getHint2() {
	return hint2;
}
public void setHint2(String hint2) {
	this.hint2 = hint2;
}
public String getHint3() {
	return hint3;
}
public void setHint3(String hint3) {
	this.hint3 = hint3;
}
public String getChr() {
	return chr;
}
public void setChr(String chr) {
	this.chr = chr;
}
  
}
