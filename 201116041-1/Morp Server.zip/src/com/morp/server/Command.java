package com.morp.server;

public class Command {

}
