package com.morp.server;

public class User {

	public Connection connection;

	public User() {

	}
}
