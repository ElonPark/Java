package com.util.db;

public class mainClass
{
    
    public static void main(String[] args)
    {
        Base base =new Base();
    
        base.method();
    
    }
    
}
